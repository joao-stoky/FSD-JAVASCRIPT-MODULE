const form = document.getElementById("formTarefa");
const input = document.getElementById("inputTarefa");
const lista = document.getElementById("listaTarefas");

// Carrega tarefas salvas ao iniciar
window.addEventListener("load", carregarTarefas);

// Evento de adicionar nova tarefa
form.addEventListener("submit", function (e) {
  e.preventDefault();

  const titulo = input.value.trim();
  if (!titulo) return;

  const tarefas = obterTarefas();

  const novaTarefa = {
    id: Date.now(),
    titulo: titulo,
    concluida: false
  };

  tarefas.push(novaTarefa);
  salvarTarefas(tarefas);
  input.value = "";
  carregarTarefas();
});

// Recupera do localStorage
function obterTarefas() {
  return JSON.parse(localStorage.getItem("tarefas")) || [];
}

// Salva no localStorage
function salvarTarefas(tarefas) {
  localStorage.setItem("tarefas", JSON.stringify(tarefas));
}

// Atualiza visual da lista
function carregarTarefas() {
  const tarefas = obterTarefas();
  lista.innerHTML = "";

  tarefas.forEach(tarefa => {
    const li = document.createElement("li");
    if (tarefa.concluida) li.classList.add("concluida");

    // Título da tarefa
    const span = document.createElement("span");
    span.textContent = tarefa.titulo;
    span.addEventListener("click", () => alternarStatus(tarefa.id));

    // Botão Remover
    const btn = document.createElement("button");
    btn.textContent = "Remover";
    btn.addEventListener("click", () => removerTarefa(tarefa.id));

    li.appendChild(span);
    li.appendChild(btn);
    lista.appendChild(li);
  });
}

// Alterna tarefa entre pendente/concluída
function alternarStatus(id) {
  const tarefas = obterTarefas();
  const index = tarefas.findIndex(t => t.id === id);
  if (index !== -1) {
    tarefas[index].concluida = !tarefas[index].concluida;
    salvarTarefas(tarefas);
    carregarTarefas();
  }
}

// Remove tarefa
function removerTarefa(id) {
  let tarefas = obterTarefas();
  tarefas = tarefas.filter(t => t.id !== id);
  salvarTarefas(tarefas);
  carregarTarefas();
}
